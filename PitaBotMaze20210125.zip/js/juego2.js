const request = new XMLHttpRequest();
request.open('GET', 'js/datosTableros.json');
request.responseType = 'json';
request.send();
request.onload = function() {
  const datosTableros = request.response;
}
